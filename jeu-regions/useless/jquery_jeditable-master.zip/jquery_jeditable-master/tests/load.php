<?php

print "External content";
